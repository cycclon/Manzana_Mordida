function reservaPropia(req, res, next) {

};

function cambiarEstadoReserva(nuevoEstado) {
    return async (req, res, next) => {

    };
};

function cambiarEstadoSena(nuevoEstado) {
    return async (req, res, next) => {

    };
};

module.exports = { reservaPropia, cambiarEstadoReserva, cambiarEstadoSena };

