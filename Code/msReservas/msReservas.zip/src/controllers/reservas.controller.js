const Reserva = require('../schemas/reserva.model');

async function solicitarReserva(req, res, next) {
    try {
        
    } catch (error) {
        
    }
};

async function pagarSena(req, res, next) {
    try {
        
    } catch (error) {
        
    }
};

async function getReserva(req, res, next) {
    try {
        
    } catch (error) {
        
    }
};

async function confirmarReserva(req, res, next) {
    try {
        
    } catch (error) {
        
    }
};

async function completarReserva(req, res, next) {
    try {
        
    } catch (error) {
        
    }
};

async function getReservas(req, res, next) {
    try {
        
    } catch (error) {
        
    }
};

module.exports = { 
    solicitarReserva,  
    pagarSena,
    getReserva,
    confirmarReserva,
    completarReserva,
    getReservas,
    pagarSena
};